import UIKit

//Note: each category is seperated through genre. each category includes my favorite song from each album in Collection Exercise 1. //
var Soul: [String] = ["Miguel: Girls Like you","Amy Winehouse: Love is a losing game","Justin timberlake: Strawberry Bubblegum"]
var RAndB: [String] = ["Miguel: Girls Like you","Amy Winehouse: Love is a losing game","Rihanna: Yeah I said it","Tory Lanez: Room 112","Ariana Grande: December","Drake: Crew Love"]
var HipHop: [String] = ["Drake: Wutang Forever","Drake: Crew Love","J Cole: 95 South","Tyler the creator: Corso","Tory Lanez: Room 112"]

for item in Soul {
    print(item)
}
print("\n")
for item in RAndB {
    print(item)
}
print("\n")
for item in HipHop {
    print(item)
}

